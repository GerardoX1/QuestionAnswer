from setuptools import setup

setup (

	name="Preguntas&Respuestas",
	version="1.6.1",
	description="""
		Modulo simple, el cual contesta preguntas de cualquier tipo desde 
		las mas simples como por ejemplo cuando nació benito juarez, 
		preguntas del tipo qué, quién, cómo, cuándo, donde por mensionar
		algunas, hasta contestar preguntas mas complejas como podrian ser 
		la opinion acerca de alguna pelicula.

		todas estas respuestas son scrapeadas de la web, y en ocaciones retorna
		datos totalmente inesperados, retornando resultados favorables un
		90% de las ocaciones.
	""",
	author="Luis Gerardo Fosado Baños",
	author_email="yeralway1@gmail.com",
	packages=["QuestionsAnswers"],
	
	)