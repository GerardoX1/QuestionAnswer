import requests
from bs4 import BeautifulSoup


class TranslatorGoogle():
    def __init__(self,proxies=False):
        if proxies:
            self.proxies={'http':'http://sistemasProxies:Adrian2010%%@mx.smartproxies.com:20000'}
        else:
            self.proxies=None
        self.url_trad='https://www.google.com/async/translate?vet=12ahUKEwibsYqynPniAhUSKa0KHXdwBFMQqDgwAHoECAkQGA..i&ei=zhcMXZuSHpLStAX34JGYBQ&client=firefox-b-d&yv=3&gsawvi=1'


    def translate(self,object):
        if type(object)==str:
            object = object.replace('.','').replace(',','').replace(';','').replace('\xa0','').replace(':','').replace('*','')
            object=[object]
        traducciones=[]
        for texto in object:
            texto = texto.replace('.','').replace(',','').replace(';','').replace('\xa0','').replace(':','').replace('*','')
            data = {
                'async': 'translate,sl:en,tl:es,st:' + texto + ',id:1561074010834,qc:true,ac:true,_id:tw-async-translate,_pms:s,_fmt:pc'}
            response = requests.post(self.url_trad,data=data,proxies=self.proxies)
            source = response.text
            self.soup = BeautifulSoup(source, 'lxml')
            #print(self.soup)
            try:
                traduccion=self.soup.find('span',id='tw-answ-target-text').text
            except:
                try:
                    url='https://www.google.com/async/translate?vet=12ahUKEwjM7dyyo_niAhUnjK0KHcq5BlgQqDgwAHoECAsQFw..i&ei=Jh8MXczCNqeYtgXK85rABQ&client=firefox-b-d&yv=3&gsawvi=1'
                    data={'async':'translate,sl:en,tl:es,st:'+texto+',id:1561075524442,qc:true,ac:true,_id:tw-async-translate,_pms:s,_fmt:pc'}
                    response = requests.post(url, data=data, proxies=self.proxies)
                    source = response.text
                    self.soup = BeautifulSoup(source, 'lxml')
                    #print(self.soup)
                    traduccion = self.soup.find('span', id='tw-answ-target-text').text
                except:
                    traduccion='No se pudo traducir'
            traducciones.append(traduccion)

        return traducciones

#'translate,sl:en,tl:es,st:hello,id:1561075524442,qc:true,ac:true,_id:tw-async-translate,_pms:s,_fmt:pc'
#'https://www.google.com/async/translate?vet=12ahUKEwjM7dyyo_niAhUnjK0KHcq5BlgQqDgwAHoECAsQFw..i&ei=Jh8MXczCNqeYtgXK85rABQ&client=firefox-b-d&yv=3&gsawvi=1'

if __name__=='__main__':
    print(TranslatorGoogle().translate(["Excuse us dear"]))